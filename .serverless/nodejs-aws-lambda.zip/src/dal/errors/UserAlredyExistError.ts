export class UserAlreadyExistError extends Error {}
